
public class GameOver {
	public static String death;
	
	// add progressive death message
	public static String DS_1() {
		return death="Just as quickly you entered this world, the cold hearted world soon took it away. Your flesh is picked off by the raviging scavengers and your bones are gound to dust by the winds of time. Your legacy is only remembered in the faintest of whispering memories";    
	}
	public static String DS_2() {
		return death="You were slain and your body left to rot in the comming seasons.You Your legacy is only held up by the passing memory of a few vilagers but grow weary of it for your tale was all too boring.";
	}
	public static String DS_TedCruz() {
		return death="";
		//please don't use
	}
}